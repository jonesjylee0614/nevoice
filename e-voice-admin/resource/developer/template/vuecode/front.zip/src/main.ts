import ArcoVue from '@arco-design/web-vue';
import ArcoVueIcon from '@arco-design/web-vue/es/icon';
import globalComponents from '@/components';
import router from './router';
import store from './store';
import i18n from './locale';
import directive from './directive';
import App from './App.vue';
import '@arco-design/web-vue/dist/arco.less';
// import '@arco-design/web-vue/dist/arco.css';
import '@/assets/style/global.less';
const app = createApp(App);

app.use(ArcoVue, {});
app.use(ArcoVueIcon);

app.use(router);
app.use(store);
app.use(i18n);
app.use(globalComponents);
app.use(directive);

// 去掉vue的警告
app.config.warnHandler = () => null;

app.mount('#app');
