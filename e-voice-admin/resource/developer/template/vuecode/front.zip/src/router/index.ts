import NProgress from 'nprogress'; // progress bar
import 'nprogress/nprogress.css';
import { createRouter, createWebHashHistory } from 'vue-router';

import { appRoutes } from './routes';
import { NOT_FOUND_ROUTE, REDIRECT_MAIN } from './routes/base';
import createRouteGuard from './guard';
NProgress.configure({ showSpinner: false }); // NProgress Configuration

const router = createRouter({
  // history: createWebHistory(),//history模式
  history: createWebHashHistory(process.env.NODE_ENV === 'production' ? '/webbusiness/' : ''), // has模式带#号
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/login/index.vue'),
      meta: {
        requiresAuth: false
      }
    },
    ...appRoutes,
    REDIRECT_MAIN,
    NOT_FOUND_ROUTE
  ],
  scrollBehavior() {
    return { top: 0 };
  }
});

createRouteGuard(router);

export default router;
