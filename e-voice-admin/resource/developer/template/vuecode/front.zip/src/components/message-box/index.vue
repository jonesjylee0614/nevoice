<template>
  <ASpin style="display: block" :loading="loading">
    <ATabs v-model:active-key="messageType" type="rounded" destroy-on-hide>
      <ATabPane v-for="item in tabList" :key="item.key">
        <template #title>
          <span>{{ t(item.title) }}{{ formatUnreadLength(item.key) }}</span>
        </template>
        <AResult v-if="!renderList.length" status="404">
          <template #subtitle>{{ $t('messageBox.noContent') }}</template>
        </AResult>
        <List :render-list="renderList" :unread-count="unreadCount" @item-click="handleItemClick" />
      </ATabPane>
      <template #extra>
        <AButton type="text" @click="emptyList">
          {{ $t('messageBox.tab.button') }}
        </AButton>
      </template>
    </ATabs>
  </ASpin>
</template>

<script lang="ts" setup>
import { useI18n } from 'vue-i18n';
import type { MessageListType, MessageRecord } from '@/api/message';
import { queryMessageList, setMessageStatus } from '@/api/message';
import useLoading from '@/hooks/loading';
import List from './list.vue';

interface TabItem {
  key: string;
  title: string;
  avatar?: string;
}
const { loading, setLoading } = useLoading(true);
const messageType = ref('message');
const { t } = useI18n();
const messageData = reactive<{
  renderList: MessageRecord[];
  messageList: MessageRecord[];
}>({
  renderList: [],
  messageList: []
});
toRefs(messageData);
const tabList: TabItem[] = [
  {
    key: 'message',
    title: 'messageBox.tab.title.message'
  },
  {
    key: 'notice',
    title: 'messageBox.tab.title.notice'
  },
  {
    key: 'todo',
    title: 'messageBox.tab.title.todo'
  }
];
async function fetchSourceData() {
  setLoading(true);
  try {
    const data = await queryMessageList();
    messageData.messageList = data.items;
  } catch (err) {
    // you can report use errorHandler or other
  } finally {
    setLoading(false);
  }
}
async function readMessage(data: MessageListType) {
  const ids = data.map(item => item.id);
  await setMessageStatus({ ids });
  fetchSourceData();
}
const renderList = computed(() => {
  return messageData.messageList.filter(item => messageType.value === item.type);
});
const unreadCount = computed(() => {
  return renderList.value.filter(item => !item.status).length;
});
const getUnreadList = (type: string) => {
  const list = messageData.messageList.filter(item => item.type === type && !item.status);
  return list;
};
const formatUnreadLength = (type: string) => {
  const list = getUnreadList(type);
  return list.length ? `(${list.length})` : ``;
};
const handleItemClick = (items: MessageListType) => {
  if (renderList.value.length) readMessage([...items]);
};
const emptyList = () => {
  messageData.messageList = [];
};
fetchSourceData();
</script>

<style scoped lang="less">
:deep(.arco-popover-popup-content) {
  padding: 0;
}

:deep(.arco-list-item-meta) {
  align-items: flex-start;
}
:deep(.arco-tabs-nav) {
  padding: 14px 0 12px 16px;
  border-bottom: 1px solid var(--color-neutral-3);
}
:deep(.arco-tabs-content) {
  padding-top: 0;
  .arco-result-subtitle {
    color: rgb(var(--gray-6));
  }
}
</style>
