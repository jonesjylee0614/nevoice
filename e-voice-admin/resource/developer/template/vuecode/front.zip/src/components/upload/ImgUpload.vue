<template>
  <div class="upimagebox">
    <div class="imagebtn">
      <div v-if="modelValue" class="upload-show-picture">
        <AImage
          :src="modelValue"
          height="90"
          :preview-visible="visibleimage"
          @preview-visible-change="
            () => {
              visibleimage = false;
            }
          "
        />
        <div class="upload-show-picture-mask">
          <ASpace>
            <icon-eye class="opbtn" @click="() => (visibleimage = true)" />
            <IconEdit class="opbtn" @click="UpImage" />
          </ASpace>
        </div>
      </div>
      <div v-else class="upload-picture-card" @click="UpImage">
        <div class="upload-picture-card-text">
          <IconPlus />
          <div style="margin-top: 10px; font-weight: 600">上传图片</div>
        </div>
      </div>
    </div>
  </div>
  <FileManage @register="registerFileModal" @success="selectImg" />
</template>

<script lang="ts" setup>
import { useModal } from '@/components/Modal';
import FileManage from '@/views/datacenter/attachment/components/FileManage.vue';

const [registerFileModal, { openModal: openFileModal }] = useModal();

const visibleimage = ref(false);
const emit = defineEmits(['update:modelValue']);

interface Props {
  multi?: boolean;
  modelValue: string;
}
const props = defineProps<Props>();
// 上传图片
const UpImage = () => {
  openFileModal(true, {
    filetype: 'image',
    getnumber: props.multi ? 'more' : 'one', // one 单张
    openfrom: 'manage' // manage管理 use 选择使用
  });
};
// 选择附件返回
const selectImg = (item: any) => {
  if (item.type == 'more') {
    item.list.forEach((img: any) => {
      console.log('多张附件返回:', img);
    });
    emit('update:modelValue', item.list);
  } else if (item.type == 'one') {
    emit('update:modelValue', item.url);
  }
};
</script>

<style lang="less" scoped>
//上传图片
.upimagebox {
  display: flex;
  .imagebtn {
    position: relative;
    width: 160px;
    height: 90px;
    background-color: var(--color-neutral-1);
    border-radius: 4px;
    overflow: hidden;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    //预览
    .upload-show-picture {
      position: relative;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      img {
        height: 100%;
      }
      &:hover {
        .upload-show-picture-mask {
          opacity: 1;
        }
      }
      .upload-show-picture-mask {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        color: var(--color-white);
        font-size: 16px;
        line-height: 90px;
        text-align: center;
        background: rgba(0, 0, 0, 0.5);
        opacity: 0;
        transition: opacity 0.1s cubic-bezier(0, 0, 1, 1);
        .opbtn {
          cursor: pointer;
        }
      }
    }
    .upload-picture-card {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      user-select: none;
      cursor: pointer;
      .upload-picture-card-text {
        text-align: center;
        color: var(--color-neutral-5);
      }
    }
  }
}
</style>
