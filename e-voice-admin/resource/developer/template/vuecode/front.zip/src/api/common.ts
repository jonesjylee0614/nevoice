import { defHttp } from '@/utils/http';
import type { UploadFileParams } from '/#/axios';
// 上传文件
// 获取配置中的上传文件路径
const DOMAIN =
  import.meta.env.VITE_APP_ENV == 'production' ? window?.globalConfig.Upload_url : window?.globalConfig.Upload_url_dev;
export function userUploadApi(
  params: UploadFileParams,
  onUploadProgress?: (progressEvent: any) => void,
  cancelToken?: any
) {
  return defHttp.uploadFile({ url: `${DOMAIN}/upload/image`, onUploadProgress, cancelToken }, params);
}
// 排序
export function tableWeigh(params: any) {
  return defHttp.post({ url: `${DOMAIN}/table/weigh`, params }, { errorMessageMode: 'message', isRootUrl: false });
}
